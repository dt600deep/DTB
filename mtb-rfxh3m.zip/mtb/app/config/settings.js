module.exports = {
	botToken: "Add Telegram Bot Token here",
	chatId: "Add Telegram Chat ID here",
};